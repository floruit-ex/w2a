package com.example.web2app_native

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.edit
import java.util.prefs.Preferences

@Composable
fun WebAppConfiguration(
    onUrlChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    // Load saved preferences
    var webUrl by remember { mutableStateOf(loadSavedUrl(context)) }
    var appName by remember { mutableStateOf(loadSavedAppName(context)) }
    
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Web App Configuration",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        
        OutlinedTextField(
            value = webUrl,
            onValueChange = { webUrl = it },
            label = { Text("Website URL") },
            placeholder = { Text("https://example.com") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth()
        )
        
        OutlinedTextField(
            value = appName,
            onValueChange = { appName = it },
            label = { Text("App Name") },
            modifier = Modifier.fillMaxWidth()
        )
        
        Button(
            onClick = {
                saveConfig(context, webUrl, appName)
                onUrlChanged(webUrl)
            },
            modifier = Modifier.align(Alignment.End)
        ) {
            Icon(imageVector = Icons.Filled.Done, contentDescription = "Save")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Save Configuration")
        }
    }
}

private fun loadSavedUrl(context: Context): String {
    return context.getSharedPreferences("webapp_config", Context.MODE_PRIVATE)
        .getString("target_url", "https://www.wl.ax/") ?: "https://www.wl.ax/"
}

private fun loadSavedAppName(context: Context): String {
    return context.getSharedPreferences("webapp_config", Context.MODE_PRIVATE)
        .getString("app_name", "Web2App") ?: "Web2App"
}

private fun saveConfig(context: Context, url: String, appName: String) {
    context.getSharedPreferences("webapp_config", Context.MODE_PRIVATE).edit {
        putString("target_url", url)
        putString("app_name", appName)
    }
}