# Web2App Native

将任何网站转换为功能齐全的原生Android应用程序。
原作者：Github@ZSW6，改编作者：Github@floruit-ex

## 改变内容
原版是需要使用Docker镜像的，现在，您只需要使用终端运行即可

## 主要特性

### 1. 核心功能
- **WebView渲染**: 完整支持HTML5、CSS3和JavaScript
- **多窗口支持**: 支持`window.open()`弹出多个webview窗口
- **URL协议支持**: 支持标准HTTP和HTTPS协议
- **文件下载**: 支持常规文件和Blob数据下载
- **离线处理**: 自定义断网提示页面

### 2. 用户界面
- **Jetpack Compose**: 现代化UI框架构建
- **Material You设计**: 遵循Google最新的设计语言
- **液态玻璃效果**: 实现毛玻璃/半透明视觉效果
- **配置界面**: 友好的用户界面用于配置Web应用参数

### 3. Intent处理
- **URL Scheme注册**: 支持自定义URL Scheme (`web2app://`)
- **深度链接支持**: 外部应用可通过链接直接打开
- **HTTP/HTTPS支持**: 直接通过网页链接启动应用

### 4. 技术架构
- **现代化架构**: 使用MVVM模式和响应式编程
- **后台服务**: APK生成和其他后台任务处理
- **安全性**: 合理的WebView安全策略配置

## 技术栈

- **Kotlin**: Android开发语言
- **Jetpack Compose**: UI框架
- **Material Design 3**: 设计系统
- **WebView**: 网页渲染引擎
- **Coroutines**: 异步处理

## 权限说明

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
    android:maxSdkVersion="29" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
```

## 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                    Android Web2App App                      │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Main Screen   │  │ Config Screen   │  │ About Screen │ │
│  │                 │  │                 │  │              │ │
│  │  ┌─────────────┐│  │  ┌───────────┐  │  │              │ │
│  │  │             ││  │  │           │  │  │              │ │
│  │  │   WebView   ││  │  │Web Params │  │  │              │ │
│  │  │             ││  │  │           │  │  │              │ │
│  │  └─────────────┘│  │  └───────────┘  │  │              │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
         ┌────────────────────┼────────────────────┐
         │                     │                    │
    ┌────▼────┐          ┌─────▼─────┐       ┌─────▼─────┐
    │Liquid   │          │Intent     │       │APK Service│
    │Glass UI │          │Handler    │       │           │
    │Effects  │          │Service    │       │           │
    └─────────┘          └───────────┘       └───────────┘
```

## 配置选项

应用支持以下可配置参数：
- 目标网站URL
- 应用名称
- 状态栏颜色
- 应用图标

## URL Scheme使用

可以通过以下方式调用应用：
- `web2app://example.com/page`
- 直接点击HTTP/HTTPS链接（如果设置了默认浏览器）

## 开发指南

### 构建项目

```bash
cd web2app_native
./gradlew build
./gradlew :app:assembleDebug
```

### 发布版本

```bash
# 生成签名密钥
keytool -genkey -v -keystore my-release-key.jks -alias alias_name -keyalg RSA -keysize 2048 -validity 10000

# 构建发布版APK
./gradlew :app:assembleRelease
```

## 注意事项

- 最低支持Android API 24 (Android 7.0)
- 需要网络权限以加载网页内容
- 对于敏感网站，请确保使用HTTPS连接
- 文件下载功能在Android 10+上需要特殊处理

## 许可证

MIT License