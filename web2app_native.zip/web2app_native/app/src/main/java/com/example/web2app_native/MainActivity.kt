package com.example.web2app_native

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.ViewGroup
import android.webkit.*
import android.widget.Toast
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.Typography
import androidx.compose.material3.Shapes
import java.io.OutputStream

class MainActivity : ComponentActivity() {

    private var targetUrl by mutableStateOf("https://www.wl.ax/")
    
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Handle incoming intents for URL schemes
        handleIncomingIntent(intent)
        
        WindowCompat.setDecorFitsSystemWindows(window, false)
        
        setContent {
            Web2AppTheme {
                MainScreen(
                    targetUrl = targetUrl,
                    activity = this
                ) { newUrl ->
                    targetUrl = newUrl
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent) {
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                intent.data?.let { uri ->
                    val url = uri.toString()
                    if (!url.startsWith("http") && !url.startsWith("https")) {
                        Toast.makeText(this, "Invalid URL scheme", Toast.LENGTH_SHORT).show()
                        return
                    }
                    targetUrl = url
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    targetUrl: String,
    activity: ComponentActivity,
    onUrlChange: (String) -> Unit
) {
    val context = LocalContext.current
    var showConfig by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Web2App Native") },
                actions = {
                    IconButton(onClick = { 
                        showConfig = !showConfig
                    }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                    IconButton(onClick = { 
                        onUrlChange(targetUrl) // Simple refresh by triggering URL change
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { paddingValues ->
        if (showConfig) {
            // Show configuration screen instead of WebView
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                LiquidGlassContainer(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    WebAppConfiguration(
                        onUrlChanged = { newUrl ->
                            onUrlChange(newUrl)
                            showConfig = false
                        }
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                setSupportMultipleWindows(true)
                                javaScriptCanOpenWindowsAutomatically = true
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                userAgentString = "$userAgentString Web2AppNative/1.0"
                            }
                            
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                    return false
                                }

                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    println("Page started loading: $url")
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    println("Page finished loading: $url")
                                }

                                override fun onReceivedError(
                                    view: WebView?, request: WebResourceRequest?, error: WebResourceError?
                                ) {
                                    // Only intercept main frame errors to prevent showing error page for resource failures
                                    if (request?.isForMainFrame == true) {
                                        view?.stopLoading()
                                        
                                        // Load custom error page
                                        val customErrorPage = """
                                            <!DOCTYPE html>
                                            <html>
                                            <head>
                                                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                                                <style>
                                                    body {
                                                        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                                                        display: flex;
                                                        flex-direction: column;
                                                        align-items: center;
                                                        justify-content: center;
                                                        height: 100vh;
                                                        margin: 0;
                                                        background-color: #f5f5f5;
                                                        color: #333;
                                                    }
                                                    .icon {
                                                        font-size: 80px;
                                                        margin-bottom: 20px;
                                                        color: #999;
                                                    }
                                                    h2 {
                                                        margin: 0 0 10px 0;
                                                        font-size: 18px;
                                                        font-weight: 600;
                                                    }
                                                    p {
                                                        margin: 0 0 30px 0;
                                                        color: #666;
                                                        font-size: 14px;
                                                        text-align: center;
                                                        padding: 0 20px;
                                                    }
                                                    button {
                                                        background-color: #007AFF;
                                                        color: white;
                                                        border: none;
                                                        padding: 12px 35px;
                                                        border-radius: 25px;
                                                        font-size: 16px;
                                                        font-weight: bold;
                                                        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                                                        transition: background-color 0.2s;
                                                    }
                                                    button:active {
                                                        background-color: #0056b3;
                                                    }
                                                </style>
                                            </head>
                                            <body>
                                                <div class="icon">📡</div>
                                                <h2>网络连接未就绪</h2>
                                                <p>检测到手机网络异常，无法连接到业务服务器。<br>请检查您的 WiFi 或移动数据设置。</p>
                                                <button onclick="location.reload()">重新加载</button>
                                            </body>
                                            </html>
                                        """.trimIndent()
                                        
                                        view?.loadDataWithBaseURL(null, customErrorPage, "text/html", "UTF-8", null)
                                    }
                                }
                            }
                            
                            webChromeClient = object : WebChromeClient() {
                                override fun onCreateWindow(
                                    view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?
                                ): Boolean {
                                    val newWebView = WebView(ctx).apply {
                                        settings.javaScriptEnabled = true
                                        settings.domStorageEnabled = true
                                        settings.setSupportMultipleWindows(true)
                                        webViewClient = WebViewClient()
                                        webChromeClient = this@apply.webChromeClient
                                    }
                                    
                                    val dialog = Dialog(ctx, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
                                    dialog.setContentView(newWebView)
                                    dialog.show()
                                    dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                                    
                                    newWebView.webChromeClient = object : WebChromeClient() {
                                        override fun onCloseWindow(window: WebView?) {
                                            dialog.dismiss()
                                        }
                                    }
                                    
                                    val transport = resultMsg?.obj as WebView.WebViewTransport
                                    transport.webView = newWebView
                                    resultMsg.sendToTarget()
                                    return true
                                }
                            }
                            
                            setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
                                try {
                                    // Handle Blob downloads
                                    if (url.startsWith("blob:")) {
                                        val js = """
                                            javascript:(function() {
                                                var xhr = new XMLHttpRequest();
                                                xhr.open('GET', '$url', true);
                                                xhr.setRequestHeader('Content-type','$mimetype');
                                                xhr.responseType = 'blob';
                                                xhr.onload = function(e) {
                                                    if (this.status == 200) {
                                                        var blobReader = new FileReader();
                                                        blobReader.readAsDataURL(this.response);
                                                        blobReader.onloadend = function() {
                                                            window.AppInterface.getBase64FromBlobData(blobReader.result, '$mimetype');
                                                        }
                                                    }
                                                };
                                                xhr.send();
                                            })()
                                        """.trimIndent()
                                        evaluateJavascript(js, null)
                                        Toast.makeText(ctx, "正在导出文件...", Toast.LENGTH_SHORT).show()
                                        return@setDownloadListener
                                    }

                                    // Process regular file downloads
                                    val request = android.app.DownloadManager.Request(Uri.parse(url))
                                    
                                    val cookies = CookieManager.getInstance().getCookie(url)
                                    if (cookies != null) request.addRequestHeader("cookie", cookies)
                                    request.addRequestHeader("User-Agent", userAgent)
                                    
                                    var fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
                                    try {
                                         fileName = java.net.URLDecoder.decode(fileName, "UTF-8")
                                    } catch (e: Exception) { }
                                    
                                    // Clean illegal characters
                                    fileName = fileName.replace("[:\\\\/*?|<>]".toRegex(), "_")
                                    
                                    request.setDescription("正在下载...")
                                    request.setTitle(fileName)
                                    request.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, fileName)
                                    
                                    val dm = ctx.getSystemService(android.content.Context.DOWNLOAD_SERVICE) as android.app.DownloadManager
                                    dm.enqueue(request)
                                    
                                    Toast.makeText(ctx, "正在下载：$fileName\n已保存到【下载】文件夹", Toast.LENGTH_LONG).show()

                                } catch (e: Exception) {
                                    android.util.Log.e("WebViewDownload", "下载失败: ${e.message}", e)
                                    Toast.makeText(ctx, "下载异常: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                            
                            // Add JavaScript interface for communication with web pages
                            val jsInterface = object {
                                @JavascriptInterface
                                fun getBase64FromBlobData(base64Data: String, mimeType: String) {
                                    convertBase64StringToPdfAndStoreIt(ctx, base64Data, mimeType)
                                }
                                
                                @JavascriptInterface
                                fun retryConnect() {
                                    post {
                                        loadUrl(targetUrl)
                                    }
                                }
                            }
                            addJavascriptInterface(jsInterface, "AppInterface")
                        }.also { webView ->
                            webView.loadUrl(targetUrl)
                        }
                    },
                    update = { webView ->
                        // Update WebView when targetUrl changes
                        if (webView.url != targetUrl) {
                            webView.loadUrl(targetUrl)
                        }
                    }
                )
            }
        }
    }
}

private fun convertBase64StringToPdfAndStoreIt(context: android.content.Context, base64Data: String, mimeType: String) {
    try {
        // Process filename
        val cleanMime = mimeType.ifEmpty { "application/octet-stream" }
        val extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(cleanMime) ?: "bin"
        val fileName = "download_${System.currentTimeMillis()}.$extension"
        
        // Remove Base64 header (data:application/pdf;base64,...)
        val pureBase64 = if (base64Data.contains(",")) {
            base64Data.split(",")[1]
        } else {
            base64Data
        }
        
        val fileBytes = Base64.decode(pureBase64, Base64.DEFAULT)

        // Save file using MediaStore (compatible with Android 10+)
        val contentValues = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, cleanMime)
            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)

        if (uri != null) {
            val outputStream: OutputStream? = resolver.openOutputStream(uri)
            outputStream?.use { it.write(fileBytes) }
            
            Toast.makeText(context, "文件已保存: $fileName", Toast.LENGTH_LONG).show()
        } else {
            throw Exception("无法创建文件 URI")
        }

    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Blob 保存失败: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun Web2AppTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    
    MaterialTheme(
        colorScheme = dynamicLightColorScheme(context),
        typography = Typography(),
        shapes = Shapes()
    ) {
        content()
    }
}

