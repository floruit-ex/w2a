# Web2App Native - 技术架构文档

## 项目概述

Web2App Native是一个将网站转换为原生Android应用的解决方案。与原始的Docker打包方案不同，本项目提供了完整的原生Android体验，具有现代化UI、液态玻璃效果和强大的Intent处理能力。

## 整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                    Presentation Layer                       │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Main Screen   │  │ Config Screen   │  │ About Screen │ │
│  │ (Jetpack Compose)│  │(Configuration)  │  │              │ │
│  │                 │  │                 │  │              │ │
│  │  ┌─────────────┐│  │  ┌───────────┐  │  │              │ │
│  │  │             ││  │  │           │  │  │              │ │
│  │  │   WebView   ││  │  │Web Params │  │  │              │ │
│  │  │             ││  │  │           │  │  │              │ │
│  │  └─────────────┘│  │  └───────────┘  │  │              │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
         ┌────────────────────┼────────────────────┐
         │                     │                    │
    ┌────▼────┐          ┌─────▼─────┐       ┌─────▼─────┐
    │Liquid   │          │Intent     │       │APK Service│
    │Glass UI │          │Handler    │       │           │
    │Effects  │          │Service    │       │           │
    └─────────┘          └───────────┘       └───────────┘
         │                     │                    │
         └─────────────────────┼────────────────────┘
                               ▼
                    ┌─────────────────────────┐
                    │    Data Layer           │
                    │  (SharedPreferences,   │
                    │   Network Requests)     │
                    └─────────────────────────┘
```

## 模块分解

### 1. 表现层 (Presentation Layer)

#### MainActivity.kt
- **职责**: 应用入口点，协调各组件工作
- **技术**: Jetpack Compose + ComponentActivity
- **功能**:
  - 处理传入Intent（URL Scheme）
  - 管理主屏幕状态
  - 协调WebView和配置界面切换

#### Web Components
- **WebView Integration**: 使用AndroidView在Compose中嵌入WebView
- **Navigation**: 支持前进后退等浏览器基本操作
- **Multi-window Support**: 实现window.open()支持

#### LiquidGlassEffect.kt
- **职责**: 提供毛玻璃/液态玻璃视觉效果
- **技术**: Compose图形层 + 渐变绘制
- **特点**: 
  - 半透明背景
  - 圆角设计
  - 海报阴影效果

### 2. 业务逻辑层 (Business Logic Layer)

#### WebAppConfig.kt
- **职责**: 管理Web应用配置参数
- **功能**:
  - URL配置存储
  - 应用名称设置
  - 参数持久化

#### APKGenerationService.kt
- **职责**: 后台APK生成服务
- **功能**:
  - 异步APK打包
  - 进度通知
  - 错误处理

### 3. 数据层 (Data Layer)

#### SharedPreferences
- 存储用户配置信息
- 保存最近使用的URL和应用设置

#### System Services
- DownloadManager: 文件下载管理
- ContentResolver: 文件访问接口

## 核心功能实现

### 1. WebView集成
```kotlin
AndroidView(
    factory = { context ->
        WebView(context).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                // ... 其他必要设置
            }
            webViewClient = CustomWebViewClient()
            webChromeClient = CustomWebChromeClient()
        }
    },
    update = { webView -> /* 更新逻辑 */ }
)
```

### 2. Intent过滤器
```xml
<intent-filter android:autoVerify="true">
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="web2app" />
</intent-filter>
```

### 3. 液态玻璃效果
```kotlin
Surface(
    modifier = modifier
        .clip(RoundedCornerShape(16.dp))
        .graphicsLayer(alpha = 0.85f)
        .background(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.25f),
                    Color.White.copy(alpha = 0.1f)
                )
            )
        ),
    color = Color.Transparent,
    shape = RoundedCornerShape(16.dp)
)
```

## 技术选型

| 方面 | 选择 | 原因 |
|------|------|------|
| UI框架 | Jetpack Compose | 现代化、声明式UI、性能优越 |
| 设计语言 | Material You | Google官方设计规范、动态色彩 |
| WebView容器 | AndroidView | 在Compose中嵌入传统视图的最佳方式 |
| 异步处理 | Kotlin Coroutines | 结构化并发、简洁易懂 |
| 状态管理 | Compose State | 符合Compose范式的状态管理 |

## 安全考虑

1. **WebView安全**:
   - 启用混合内容模式以支持HTTPS资源
   - 设置适当的安全头
   - 验证外部链接

2. **权限管理**:
   - 最小权限原则
   - Android 10+存储权限适配

3. **数据保护**:
   - 敏感信息加密存储
   - 网络通信使用HTTPS

## 性能优化

1. **内存管理**:
   - WebView资源及时释放
   - 图片懒加载
   - 内存泄漏防护

2. **渲染优化**:
   - Compose重组最小化
   - View层次简化
   - GPU加速启用

## 扩展性设计

1. **模块化架构**: 各组件职责清晰，易于扩展
2. **可配置性**: 支持多种Web应用参数定制
3. **插件化预留**: 为未来功能扩展留出接口

## 部署说明

### 开发环境要求
- Android Studio Flamingo+ 或更高版本
- Android SDK API Level 34
- Gradle 8.0+

### 构建命令
```bash
# 调试版本
./gradlew :app:assembleDebug

# 发布版本  
./gradlew :app:assembleRelease
```

## 测试覆盖

1. **单元测试**: 业务逻辑验证
2. **集成测试**: UI交互流程
3. **兼容性测试**: 不同Android版本适配

---

*本文档最后更新于 2026年3月*