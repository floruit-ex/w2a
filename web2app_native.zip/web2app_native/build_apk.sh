#!/bin/bash

# Web2App Native - APK构建脚本
# 用于自动化构建调试版和发布版APK

set -e  # 遇到错误立即退出

echo "==================================="
echo "Web2App Native - APK构建脚本"
echo "==================================="

# 检查是否在项目根目录
if [ ! -f "settings.gradle.kts" ] || [ ! -d "app" ]; then
    echo "错误: 当前不在项目根目录!"
    echo "请切换到 web2app_native 项目目录再运行此脚本"
    exit 1
fi

# 显示帮助信息
show_help() {
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  -d, --debug     构建调试版本 (默认)"
    echo "  -r, --release   构建发布版本"
    echo "  -a, --all       构建所有版本"
    echo "  -c, --clean     清理构建缓存"
    echo "  -h, --help      显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  $0              # 构建调试版本"
    echo "  $0 -r           # 构建发布版本"
    echo "  $0 -a           # 构建所有版本"
}

# 默认构建类型
BUILD_TYPE="debug"

# 解析命令行参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -d|--debug)
            BUILD_TYPE="debug"
            shift
            ;;
        -r|--release)
            BUILD_TYPE="release"
            shift
            ;;
        -a|--all)
            BUILD_TYPE="all"
            shift
            ;;
        -c|--clean)
            echo "正在清理构建缓存..."
            ./gradlew clean
            echo "清理完成!"
            exit 0
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            echo "未知参数: $1"
            show_help
            exit 1
            ;;
    esac
done

# 检查Gradle Wrapper是否存在
if [ ! -f "gradlew" ]; then
    echo "错误: 找不到 gradlew 文件!"
    exit 1
fi

# 确保gradlew有执行权限
chmod +x gradlew

echo "开始构建..."

case $BUILD_TYPE in
    debug)
        echo "构建调试版本..."
        ./gradlew :app:assembleDebug
        
        DEBUG_APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
        if [ -f "$DEBUG_APK_PATH" ]; then
            echo "✅ 调试版本构建成功!"
            echo "📁 APK位置: $(pwd)/$DEBUG_APK_PATH"
            echo "📏 文件大小: $(du -h "$DEBUG_APK_PATH" | cut -f1)"
        else
            echo "❌ 调试版本构建失败!"
            exit 1
        fi
        ;;
    
    release)
        echo "构建发布版本..."
        ./gradlew :app:assembleRelease
        
        RELEASE_APK_PATH="app/build/outputs/apk/release/app-release-unsigned.apk"
        if [ -f "$RELEASE_APK_PATH" ]; then
            echo "✅ 发布版本(未签名)构建成功!"
            echo "📁 APK位置: $(pwd)/$RELEASE_APK_PATH"
            echo "📏 文件大小: $(du -h "$RELEASE_APK_PATH" | cut -f1)"
        else
            # 尝试查找已签名的APK
            SIGNED_RELEASE_PATH="app/build/outputs/apk/release/app-release.apk"
            if [ -f "$SIGNED_RELEASE_PATH" ]; then
                echo "✅ 发布版本(已签名)构建成功!"
                echo "📁 APK位置: $(pwd)/$SIGNED_RELEASE_PATH"
                echo "📏 文件大小: $(du -h "$SIGNED_RELEASE_PATH" | cut -f1)"
            else
                echo "❌ 发布版本构建失败!"
                exit 1
            fi
        fi
        ;;
    
    all)
        echo "构建所有版本..."
        
        # 构建调试版本
        ./gradlew :app:assembleDebug
        DEBUG_APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
        if [ -f "$DEBUG_APK_PATH" ]; then
            echo "✅ 调试版本构建成功! ($DEBUG_APK_PATH)"
        else
            echo "❌ 调试版本构建失败!"
            exit 1
        fi
        
        # 构建发布版本
        ./gradlew :app:assembleRelease
        RELEASE_APK_PATH="app/build/outputs/apk/release/app-release-unsigned.apk"
        if [ -f "$RELEASE_APK_PATH" ]; then
            echo "✅ 发布版本(未签名)构建成功! ($RELEASE_APK_PATH)"
        elif [ -f "app/build/outputs/apk/release/app-release.apk" ]; then
            echo "✅ 发布版本(已签名)构建成功! (app/build/outputs/apk/release/app-release.apk)"
        else
            echo "❌ 发布版本构建失败!"
            exit 1
        fi
        
        echo "✅ 所有版本构建完成!"
        ;;
esac

echo ""
echo "==================================="
echo "构建完成!"
echo "==================================="

# 列出生成的所有APK文件
echo "可用的APK文件:"
find app/build/outputs/apk -name "*.apk" -exec ls -lh {} \; 2>/dev/null || echo "无可用APK文件"

echo ""
echo "💡 提示:"
echo "- 使用 'adb install [APK路径]' 安装到设备"
echo "- 调试APK通常位于 app/build/outputs/apk/debug/"
echo "- 发布APK通常位于 app/build/outputs/apk/release/"